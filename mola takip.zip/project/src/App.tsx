import React, { useState, useEffect } from 'react';
import { Search, Users, Clock, BarChart3, Bell, Plus } from 'lucide-react';
import EmployeeList from './components/EmployeeList';
import AddEmployeeModal from './components/AddEmployeeModal';
import ActiveBreaks from './components/ActiveBreaks';
import Notifications from './components/Notifications';
import DailyReportComponent from './components/DailyReport';
import { Employee, Break, DailyReport, Notification } from './types';

function App() {
  const [employees, setEmployees] = useState<Employee[]>([
    { id: '1', name: 'Ahmet Yılmaz', department: 'Yazılım Geliştirme' },
    { id: '2', name: 'Elif Kaya', department: 'Pazarlama' },
    { id: '3', name: 'Mehmet Demir', department: 'İnsan Kaynakları' },
    { id: '4', name: 'Ayşe Öztürk', department: 'Muhasebe' },
    { id: '5', name: 'Murat Şen', department: 'Satış' },
    { id: '6', name: 'Zeynep Akar', department: 'Destek' },
  ]);

  const [activeBreaks, setActiveBreaks] = useState<Break[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [dailyReports, setDailyReports] = useState<DailyReport[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'employees' | 'breaks' | 'reports' | 'notifications'>('employees');
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Filter employees based on search term
  const filteredEmployees = employees.filter(employee =>
    employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Timer effect for active breaks
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveBreaks(prevBreaks => {
        const updatedBreaks = [...prevBreaks];
        const completedBreaks: Break[] = [];

        // Check for completed breaks
        prevBreaks.forEach(breakItem => {
          const elapsed = Math.floor((Date.now() - breakItem.startTime.getTime()) / 1000 / 60);
          if (elapsed >= breakItem.duration && breakItem.isActive) {
            // Break is completed
            const completedBreak = { ...breakItem, isActive: false, endTime: new Date() };
            completedBreaks.push(completedBreak);
            
            // Add notification
            const notification: Notification = {
              id: Date.now().toString() + Math.random(),
              employeeName: breakItem.employeeName,
              breakType: getBreakTypeLabel(breakItem.type),
              message: `${getBreakTypeLabel(breakItem.type)} süresi tamamlandı`,
              timestamp: new Date(),
              isRead: false,
            };
            
            setNotifications(prev => [notification, ...prev]);
            
            // Update daily report
            updateDailyReport(breakItem);
          }
        });

        // Remove completed breaks from active list
        return updatedBreaks.filter(breakItem => {
          const elapsed = Math.floor((Date.now() - breakItem.startTime.getTime()) / 1000 / 60);
          return elapsed < breakItem.duration && breakItem.isActive;
        });
      });
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  }, []);

  const getBreakTypeLabel = (type: string) => {
    switch (type) {
      case 'lunch': return 'Yemek Molası';
      case 'tea1': return '1. Çay Molası';
      case 'tea2': return '2. Çay Molası';
      default: return type;
    }
  };

  const getBreakDuration = (type: 'lunch' | 'tea1' | 'tea2') => {
    switch (type) {
      case 'lunch': return 30;
      case 'tea1': return 15;
      case 'tea2': return 15;
    }
  };

  const handleAddEmployee = (name: string, department: string) => {
    const newEmployee: Employee = {
      id: Date.now().toString(),
      name,
      department,
    };
    setEmployees(prev => [...prev, newEmployee]);
  };

  const handleDeleteEmployee = (employeeId: string) => {
    // End any active breaks for this employee
    const employeeActiveBreaks = activeBreaks.filter(b => b.employeeId === employeeId);
    employeeActiveBreaks.forEach(breakItem => {
      handleEndBreak(breakItem.id);
    });

    // Remove employee
    setEmployees(prev => prev.filter(e => e.id !== employeeId));
  };

  const handleStartBreak = (employeeId: string, type: 'lunch' | 'tea1' | 'tea2') => {
    const employee = employees.find(e => e.id === employeeId);
    if (!employee) return;

    const newBreak: Break = {
      id: Date.now().toString(),
      employeeId,
      employeeName: employee.name,
      type,
      startTime: new Date(),
      duration: getBreakDuration(type),
      isActive: true,
    };

    setActiveBreaks(prev => [...prev, newBreak]);

    // Add start notification
    const notification: Notification = {
      id: Date.now().toString() + Math.random(),
      employeeName: employee.name,
      breakType: getBreakTypeLabel(type),
      message: `${getBreakTypeLabel(type)} başladı`,
      timestamp: new Date(),
      isRead: false,
    };
    
    setNotifications(prev => [notification, ...prev]);
  };

  const handleEndBreak = (breakId: string) => {
    const breakToEnd = activeBreaks.find(b => b.id === breakId);
    if (!breakToEnd) return;

    const endTime = new Date();
    const actualDuration = Math.floor((endTime.getTime() - breakToEnd.startTime.getTime()) / 1000 / 60);
    const isEarlyEnd = actualDuration < breakToEnd.duration;

    const completedBreak: Break = {
      ...breakToEnd,
      endTime,
      isActive: false,
      isManuallyEnded: true,
    };

    // Remove from active breaks
    setActiveBreaks(prev => prev.filter(b => b.id !== breakId));

    // Add notification
    const notification: Notification = {
      id: Date.now().toString() + Math.random(),
      employeeName: breakToEnd.employeeName,
      breakType: getBreakTypeLabel(breakToEnd.type),
      message: isEarlyEnd 
        ? `${getBreakTypeLabel(breakToEnd.type)} erken bitirildi (${actualDuration}/${breakToEnd.duration} dk)`
        : `${getBreakTypeLabel(breakToEnd.type)} tamamlandı`,
      timestamp: new Date(),
      isRead: false,
    };
    
    setNotifications(prev => [notification, ...prev]);

    // Update daily report
    updateDailyReport(completedBreak, actualDuration);
  };

  const updateDailyReport = (breakItem: Break, actualDuration?: number) => {
    const today = new Date().toISOString().split('T')[0];
    const duration = actualDuration || breakItem.duration;

    setDailyReports(prev => {
      const existingReport = prev.find(r => r.employeeId === breakItem.employeeId && r.date === today);
      
      if (existingReport) {
        return prev.map(r => {
          if (r.employeeId === breakItem.employeeId && r.date === today) {
            return {
              ...r,
              totalBreakMinutes: r.totalBreakMinutes + duration,
              usedBreaks: {
                ...r.usedBreaks,
                [breakItem.type]: r.usedBreaks[breakItem.type] + duration,
              },
            };
          }
          return r;
        });
      } else {
        const newReport: DailyReport = {
          employeeId: breakItem.employeeId,
          employeeName: breakItem.employeeName,
          date: today,
          totalBreakMinutes: duration,
          usedBreaks: {
            lunch: breakItem.type === 'lunch' ? duration : 0,
            tea1: breakItem.type === 'tea1' ? duration : 0,
            tea2: breakItem.type === 'tea2' ? duration : 0,
          },
          unusedBreaks: [],
        };
        return [...prev, newReport];
      }
    });
  };

  const handleMarkAsRead = (notificationId: string) => {
    setNotifications(prev =>
      prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
    );
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
  };

  const getFilteredReports = () => {
    return dailyReports.filter(report => report.date === selectedDate);
  };

  const unreadNotifications = notifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-lg border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">Mola Takip Sistemi</h1>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Personel ara..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
                />
              </div>
              
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Personel Ekle
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('employees')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'employees'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Personeller
              </div>
            </button>
            
            <button
              onClick={() => setActiveTab('breaks')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'breaks'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Aktif Molalar
                {activeBreaks.length > 0 && (
                  <span className="bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full">
                    {activeBreaks.length}
                  </span>
                )}
              </div>
            </button>
            
            <button
              onClick={() => setActiveTab('reports')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'reports'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Raporlar
              </div>
            </button>
            
            <button
              onClick={() => setActiveTab('notifications')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'notifications'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Bildirimler
                {unreadNotifications > 0 && (
                  <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                    {unreadNotifications}
                  </span>
                )}
              </div>
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'employees' && (
          <EmployeeList
            employees={filteredEmployees}
            activeBreaks={activeBreaks}
            onStartBreak={handleStartBreak}
            onEndBreak={handleEndBreak}
            onDeleteEmployee={handleDeleteEmployee}
          />
        )}

        {activeTab === 'breaks' && (
          <ActiveBreaks
            activeBreaks={activeBreaks}
            onEndBreak={handleEndBreak}
          />
        )}

        {activeTab === 'reports' && (
          <DailyReportComponent
            employees={employees}
            reports={getFilteredReports()}
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
          />
        )}

        {activeTab === 'notifications' && (
          <Notifications
            notifications={notifications}
            onMarkAsRead={handleMarkAsRead}
            onClearAll={handleClearAllNotifications}
          />
        )}
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            Bu uygulama <span className="font-medium text-gray-700">Fuat Demirci</span> tarafından geliştirilmiştir.
          </p>
        </div>
      </footer>

      {/* Add Employee Modal */}
      <AddEmployeeModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddEmployee={handleAddEmployee}
      />
    </div>
  );
}

export default App;