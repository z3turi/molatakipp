export interface Employee {
  id: string;
  name: string;
  department: string;
}

export interface Break {
  id: string;
  employeeId: string;
  employeeName: string;
  type: 'lunch' | 'tea1' | 'tea2';
  startTime: Date;
  endTime?: Date;
  duration: number; // in minutes
  isActive: boolean;
  isManuallyEnded?: boolean;
}

export interface DailyReport {
  employeeId: string;
  employeeName: string;
  date: string;
  totalBreakMinutes: number;
  usedBreaks: {
    lunch: number;
    tea1: number;
    tea2: number;
  };
  unusedBreaks: string[];
}

export interface Notification {
  id: string;
  employeeName: string;
  breakType: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
}