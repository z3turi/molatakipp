import React from 'react';
import { BarChart3, Calendar, Clock, TrendingUp } from 'lucide-react';
import { DailyReport, Employee } from '../types';

interface DailyReportProps {
  employees: Employee[];
  reports: DailyReport[];
  selectedDate: string;
  onDateChange: (date: string) => void;
}

const DailyReportComponent: React.FC<DailyReportProps> = ({
  employees,
  reports,
  selectedDate,
  onDateChange,
}) => {
  const today = new Date().toISOString().split('T')[0];
  const totalEmployees = employees.length;
  const activeEmployees = reports.length;
  const totalBreakMinutes = reports.reduce((sum, report) => sum + report.totalBreakMinutes, 0);
  const averageBreakMinutes = activeEmployees > 0 ? Math.round(totalBreakMinutes / activeEmployees) : 0;

  const getBreakTypeLabel = (type: string) => {
    switch (type) {
      case 'lunch': return 'Yemek';
      case 'tea1': return '1. Çay';
      case 'tea2': return '2. Çay';
      default: return type;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-blue-600" />
          Günlük Rapor
        </h2>
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-gray-500" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => onDateChange(e.target.value)}
            max={today}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-800">Toplam Personel</span>
          </div>
          <p className="text-2xl font-bold text-blue-900">{totalEmployees}</p>
        </div>

        <div className="bg-green-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-green-600" />
            <span className="text-sm font-medium text-green-800">Aktif Personel</span>
          </div>
          <p className="text-2xl font-bold text-green-900">{activeEmployees}</p>
        </div>

        <div className="bg-orange-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-orange-600" />
            <span className="text-sm font-medium text-orange-800">Toplam Mola</span>
          </div>
          <p className="text-2xl font-bold text-orange-900">{totalBreakMinutes} dk</p>
        </div>

        <div className="bg-purple-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-5 h-5 text-purple-600" />
            <span className="text-sm font-medium text-purple-800">Ortalama</span>
          </div>
          <p className="text-2xl font-bold text-purple-900">{averageBreakMinutes} dk</p>
        </div>
      </div>

      {/* Employee Reports */}
      {reports.length === 0 ? (
        <div className="text-center py-8">
          <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Seçilen tarih için veri bulunmuyor</p>
        </div>
      ) : (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900 mb-3">Personel Detayları</h3>
          {reports.map(report => (
            <div key={report.employeeId} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-gray-900">{report.employeeName}</h4>
                <span className="text-sm font-semibold text-blue-600">
                  Toplam: {report.totalBreakMinutes} dakika
                </span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h5 className="text-sm font-medium text-gray-700 mb-2">Kullanılan Molalar:</h5>
                  <div className="space-y-1">
                    {Object.entries(report.usedBreaks).map(([type, minutes]) => (
                      <div key={type} className="flex justify-between text-sm">
                        <span className="text-gray-600">{getBreakTypeLabel(type)}</span>
                        <span className="font-medium text-green-600">{minutes} dk</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                {report.unusedBreaks.length > 0 && (
                  <div>
                    <h5 className="text-sm font-medium text-gray-700 mb-2">Kullanılmayan Molalar:</h5>
                    <div className="space-y-1">
                      {report.unusedBreaks.map((type, index) => (
                        <span key={index} className="inline-block text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded mr-1">
                          {getBreakTypeLabel(type)}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DailyReportComponent;