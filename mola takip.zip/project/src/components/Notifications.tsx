import React from 'react';
import { Bell, CheckCircle, Clock, X } from 'lucide-react';
import { Notification } from '../types';

interface NotificationsProps {
  notifications: Notification[];
  onMarkAsRead: (notificationId: string) => void;
  onClearAll: () => void;
}

const Notifications: React.FC<NotificationsProps> = ({
  notifications,
  onMarkAsRead,
  onClearAll,
}) => {
  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <Bell className="w-6 h-6 text-blue-600" />
          Bildirimler
          {unreadCount > 0 && (
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
              {unreadCount}
            </span>
          )}
        </h2>
        {notifications.length > 0 && (
          <button
            onClick={onClearAll}
            className="text-sm text-gray-500 hover:text-gray-700 transition-colors"
          >
            Tümünü Temizle
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="text-center py-8">
          <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Henüz bildirim bulunmuyor</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {notifications.map(notification => (
            <div
              key={notification.id}
              className={`p-3 rounded-lg border transition-all duration-200 ${
                notification.isRead
                  ? 'bg-gray-50 border-gray-200'
                  : 'bg-blue-50 border-blue-200 shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 flex-1">
                  <div className={`p-1.5 rounded-full mt-0.5 ${
                    notification.isRead ? 'bg-gray-200' : 'bg-blue-100'
                  }`}>
                    <Clock className={`w-3 h-3 ${
                      notification.isRead ? 'text-gray-500' : 'text-blue-600'
                    }`} />
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm ${
                      notification.isRead ? 'text-gray-600' : 'text-gray-900'
                    }`}>
                      <span className="font-semibold">{notification.employeeName}</span> - {notification.message}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {notification.timestamp.toLocaleString('tr-TR')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {!notification.isRead && (
                    <button
                      onClick={() => onMarkAsRead(notification.id)}
                      className="p-1 text-blue-600 hover:bg-blue-100 rounded-full transition-colors"
                      title="Okundu olarak işaretle"
                    >
                      <CheckCircle className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Notifications;