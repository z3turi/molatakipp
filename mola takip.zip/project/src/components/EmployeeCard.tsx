import React from 'react';
import { Clock, Coffee, Utensils, User } from 'lucide-react';
import { Employee, Break } from '../types';

interface EmployeeCardProps {
  employee: Employee;
  activeBreaks: Break[];
  onStartBreak: (employeeId: string, type: 'lunch' | 'tea1' | 'tea2') => void;
  onEndBreak: (breakId: string) => void;
}

const EmployeeCard: React.FC<EmployeeCardProps> = ({
  employee,
  activeBreaks,
  onStartBreak,
  onEndBreak,
}) => {
  const employeeActiveBreaks = activeBreaks.filter(b => b.employeeId === employee.id);
  const hasActiveBreak = employeeActiveBreaks.length > 0;

  const getBreakTypeLabel = (type: string) => {
    switch (type) {
      case 'lunch': return 'Yemek Molası';
      case 'tea1': return '1. Çay Molası';
      case 'tea2': return '2. Çay Molası';
      default: return type;
    }
  };

  const getBreakDuration = (type: string) => {
    switch (type) {
      case 'lunch': return 30;
      case 'tea1': return 15;
      case 'tea2': return 15;
      default: return 0;
    }
  };

  const getRemainingTime = (breakItem: Break) => {
    const elapsed = Math.floor((Date.now() - breakItem.startTime.getTime()) / 1000 / 60);
    const remaining = breakItem.duration - elapsed;
    return Math.max(0, remaining);
  };

  return (
    <div className={`bg-white rounded-xl shadow-lg border-2 transition-all duration-300 hover:shadow-xl ${
      hasActiveBreak 
        ? 'border-orange-400 bg-gradient-to-br from-orange-50 to-white' 
        : 'border-gray-200 hover:border-blue-300'
    }`}>
      <div className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className={`p-2 rounded-full ${hasActiveBreak ? 'bg-orange-100' : 'bg-blue-100'}`}>
            <User className={`w-5 h-5 ${hasActiveBreak ? 'text-orange-600' : 'text-blue-600'}`} />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{employee.name}</h3>
            <p className="text-sm text-gray-500">{employee.department}</p>
          </div>
        </div>

        {hasActiveBreak && (
          <div className="mb-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
            {employeeActiveBreaks.map(breakItem => (
              <div key={breakItem.id} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-orange-600" />
                  <span className="text-sm font-medium text-orange-800">
                    {getBreakTypeLabel(breakItem.type)} - {getRemainingTime(breakItem)} dk kaldı
                  </span>
                </div>
                <button
                  onClick={() => onEndBreak(breakItem.id)}
                  className="text-xs bg-orange-600 text-white px-3 py-1 rounded-full hover:bg-orange-700 transition-colors"
                >
                  Bitir
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 gap-2">
          <button
            onClick={() => onStartBreak(employee.id, 'lunch')}
            disabled={hasActiveBreak}
            className="flex items-center justify-center gap-2 p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            <Utensils className="w-4 h-4" />
            <span className="font-medium">Yemek Molası (30dk)</span>
          </button>
          
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onStartBreak(employee.id, 'tea1')}
              disabled={hasActiveBreak}
              className="flex items-center justify-center gap-2 p-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-sm"
            >
              <Coffee className="w-4 h-4" />
              <span>1. Çay (15dk)</span>
            </button>
            
            <button
              onClick={() => onStartBreak(employee.id, 'tea2')}
              disabled={hasActiveBreak}
              className="flex items-center justify-center gap-2 p-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-sm"
            >
              <Coffee className="w-4 h-4" />
              <span>2. Çay (15dk)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeCard;