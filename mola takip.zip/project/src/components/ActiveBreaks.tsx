import React from 'react';
import { Clock, User, AlertCircle } from 'lucide-react';
import { Break } from '../types';

interface ActiveBreaksProps {
  activeBreaks: Break[];
  onEndBreak: (breakId: string) => void;
}

const ActiveBreaks: React.FC<ActiveBreaksProps> = ({ activeBreaks, onEndBreak }) => {
  const getBreakTypeLabel = (type: string) => {
    switch (type) {
      case 'lunch': return 'Yemek Molası';
      case 'tea1': return '1. Çay Molası';
      case 'tea2': return '2. Çay Molası';
      default: return type;
    }
  };

  const getRemainingTime = (breakItem: Break) => {
    const elapsed = Math.floor((Date.now() - breakItem.startTime.getTime()) / 1000 / 60);
    const remaining = breakItem.duration - elapsed;
    return Math.max(0, remaining);
  };

  const isOvertime = (breakItem: Break) => {
    const elapsed = Math.floor((Date.now() - breakItem.startTime.getTime()) / 1000 / 60);
    return elapsed > breakItem.duration;
  };

  if (activeBreaks.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Clock className="w-6 h-6 text-blue-600" />
          Aktif Molalar
        </h2>
        <div className="text-center py-8">
          <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Şu anda aktif mola bulunmuyor</p>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
        <Clock className="w-6 h-6 text-blue-600" />
        Aktif Molalar ({activeBreaks.length})
      </h2>
      
      <div className="space-y-3">
        {activeBreaks.map(breakItem => {
          const remaining = getRemainingTime(breakItem);
          const overtime = isOvertime(breakItem);
          
          return (
            <div
              key={breakItem.id}
              className={`p-4 rounded-lg border-2 transition-all duration-300 ${
                overtime 
                  ? 'bg-red-50 border-red-200' 
                  : 'bg-blue-50 border-blue-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${overtime ? 'bg-red-100' : 'bg-blue-100'}`}>
                    <User className={`w-4 h-4 ${overtime ? 'text-red-600' : 'text-blue-600'}`} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{breakItem.employeeName}</h3>
                    <p className={`text-sm ${overtime ? 'text-red-600' : 'text-blue-600'}`}>
                      {getBreakTypeLabel(breakItem.type)}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    {overtime ? (
                      <div className="flex items-center gap-1 text-red-600">
                        <AlertCircle className="w-4 h-4" />
                        <span className="font-bold">Süre Aşıldı!</span>
                      </div>
                    ) : (
                      <span className="font-bold text-blue-600">{remaining} dk kaldı</span>
                    )}
                    <p className="text-xs text-gray-500">
                      {breakItem.startTime.toLocaleTimeString('tr-TR', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })} başladı
                    </p>
                  </div>
                  
                  <button
                    onClick={() => onEndBreak(breakItem.id)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      overtime 
                        ? 'bg-red-600 hover:bg-red-700 text-white' 
                        : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                  >
                    Bitir
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ActiveBreaks;