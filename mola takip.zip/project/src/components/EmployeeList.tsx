import React, { useState } from 'react';
import { User, Clock, Coffee, Utensils, ChevronRight, Trash2 } from 'lucide-react';
import { Employee, Break } from '../types';

interface EmployeeListProps {
  employees: Employee[];
  activeBreaks: Break[];
  onStartBreak: (employeeId: string, type: 'lunch' | 'tea1' | 'tea2') => void;
  onEndBreak: (breakId: string) => void;
  onDeleteEmployee: (employeeId: string) => void;
}

const EmployeeList: React.FC<EmployeeListProps> = ({
  employees,
  activeBreaks,
  onStartBreak,
  onEndBreak,
  onDeleteEmployee,
}) => {
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);

  const getEmployeeActiveBreak = (employeeId: string) => {
    return activeBreaks.find(b => b.employeeId === employeeId);
  };

  const getBreakTypeLabel = (type: string) => {
    switch (type) {
      case 'lunch': return 'Yemek Molası';
      case 'tea1': return '1. Çay Molası';
      case 'tea2': return '2. Çay Molası';
      default: return type;
    }
  };

  const getRemainingTime = (breakItem: Break) => {
    const elapsed = Math.floor((Date.now() - breakItem.startTime.getTime()) / 1000 / 60);
    const remaining = breakItem.duration - elapsed;
    return Math.max(0, remaining);
  };

  const handleEmployeeClick = (employeeId: string) => {
    setSelectedEmployee(selectedEmployee === employeeId ? null : employeeId);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <User className="w-6 h-6 text-blue-600" />
          Personel Listesi ({employees.length})
        </h2>
      </div>

      <div className="divide-y divide-gray-200">
        {employees.map(employee => {
          const activeBreak = getEmployeeActiveBreak(employee.id);
          const isSelected = selectedEmployee === employee.id;
          
          return (
            <div key={employee.id} className="transition-all duration-200">
              <div
                onClick={() => handleEmployeeClick(employee.id)}
                className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                  activeBreak ? 'bg-orange-50' : ''
                } ${isSelected ? 'bg-blue-50' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className={`p-2 rounded-full ${
                      activeBreak ? 'bg-orange-100' : 'bg-blue-100'
                    }`}>
                      <User className={`w-4 h-4 ${
                        activeBreak ? 'text-orange-600' : 'text-blue-600'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{employee.name}</h3>
                      <p className="text-sm text-gray-500">{employee.department}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {activeBreak && (
                      <div className="text-right mr-3">
                        <p className="text-sm font-medium text-orange-600">
                          {getBreakTypeLabel(activeBreak.type)}
                        </p>
                        <p className="text-xs text-orange-500">
                          {getRemainingTime(activeBreak)} dk kaldı
                        </p>
                      </div>
                    )}
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteEmployee(employee.id);
                      }}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Personeli Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${
                      isSelected ? 'rotate-90' : ''
                    }`} />
                  </div>
                </div>
              </div>

              {isSelected && (
                <div className="px-4 pb-4 bg-gray-50 border-t border-gray-200">
                  {activeBreak ? (
                    <div className="p-3 bg-orange-100 rounded-lg border border-orange-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-orange-600" />
                          <span className="text-sm font-medium text-orange-800">
                            {getBreakTypeLabel(activeBreak.type)} devam ediyor
                          </span>
                        </div>
                        <button
                          onClick={() => onEndBreak(activeBreak.id)}
                          className="px-3 py-1 bg-orange-600 text-white text-sm rounded-lg hover:bg-orange-700 transition-colors"
                        >
                          Molayı Bitir
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-2 mt-3">
                      <button
                        onClick={() => onStartBreak(employee.id, 'lunch')}
                        className="flex items-center justify-center gap-2 p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <Utensils className="w-4 h-4" />
                        <span className="font-medium">Yemek Molası (30dk)</span>
                      </button>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => onStartBreak(employee.id, 'tea1')}
                          className="flex items-center justify-center gap-2 p-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          <Coffee className="w-4 h-4" />
                          <span>1. Çay (15dk)</span>
                        </button>
                        
                        <button
                          onClick={() => onStartBreak(employee.id, 'tea2')}
                          className="flex items-center justify-center gap-2 p-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          <Coffee className="w-4 h-4" />
                          <span>2. Çay (15dk)</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {employees.length === 0 && (
        <div className="text-center py-8">
          <User className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Henüz personel eklenmemiş</p>
        </div>
      )}
    </div>
  );
};

export default EmployeeList;